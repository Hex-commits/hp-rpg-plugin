var swap = 0, alignSwitch = 0;
var ele, unedited, currentChar, colorcode;
var edited = "";
var areaText = 0;

callOptions();

function callOptions (){
	backup();
	chrome.storage.sync.get("color", function(result) {
		console.log('Value currently is ' + result.color);
		colorcode = result.color;
		DetectBox();
		addColor();
	});

}
		
		
function backup() {
	
	chrome.storage.sync.set({"backup": unedited}, function() {
          console.log('Backup is ::::: ' + unedited);
        });
}	
function DetectBox(){
		ele = document.getElementsByClassName('redactor-editor');
		unedited = ele[0].innerHTML;


	
	
}

function clearCode(textToClear) {
	alignSwitch = 0;
	var editedClear = "";
	for(var i = 0; i <= textToClear.length -1; i++) {
		currentChar = textToClear.charAt(i);
		
		
		if(currentChar == '[') {
			alignSwitch = 1;
			} else if(currentChar == ']'){
				alignSwitch = 0;
				continue;
			}
			
		if(alignSwitch == 0) {
			editedClear = editedClear + currentChar;
		}
		
	}
	return editedClear;
}


function addColor(){
	chrome.storage.sync.get("setClear", function(result) {
		console.log('Clear currently is ' + result.setClear);
		
		if(result.setClear == true){
			unedited = clearCode(unedited);
		}
		for(var i = 0; i <= unedited.length -1; i++) {
			currentChar = unedited.charAt(i);
			if((currentChar == '"' && swap == 0) || (currentChar == '»' && swap == 0)) {
				swap = 1;
				edited = edited + "[color=" + colorcode + "]" + currentChar;
			} else if((currentChar == '"' && swap == 1) || (currentChar == '«' && swap == 1)){
				swap = 0;
				edited = edited + currentChar + "[/color]" ;
			} else{
				edited = edited + currentChar;
			}
		}
		ele[0].innerHTML = "[align=justify]" + edited + "[/align]";
		
	});
	
	
}


