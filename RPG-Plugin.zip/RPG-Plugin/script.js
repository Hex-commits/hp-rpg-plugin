window.addEventListener('load', function load(event) {
	chrome.storage.sync.get("color", function(result) {
        if (result != undefined && result.color != undefined) {
            document.getElementById('colorc').value = result.color;
        }
		
    });
	chrome.storage.sync.get("setClear", function(result) {
        if (result != undefined) {
			document.getElementById('setClear').checked = result.setClear;
			console.log('value is ' + result.setClear);
        }
    });
	
	document.getElementById('colorc').onchange = function() {
		  if(document.getElementById('colorc').value.length !== 7 || document.getElementById('colorc').value.charAt(0) !== '#') {
			document.getElementById('save').disabled = true;
		  } else {
			 document.getElementById('save').disabled = false;
		  }
	}
    document.getElementById('save').onclick = function() {
         chrome.storage.sync.set({"color": document.getElementById('colorc').value, "setClear": document.getElementById('setClear').checked}, function() {
          console.log('Value is set to ' + document.getElementById('colorc').value + " and " + document.getElementById('setClear').checked);
		  console.log('Value.length: ' + document.getElementById('colorc').value.length);
		 
        });
    };
	
	chrome.storage.sync.get("backup", function(result) {
        if (result != undefined) {
            document.getElementById('backup').value = result.backup;
        }
    });
});