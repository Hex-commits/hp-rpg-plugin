var swap = 0, alignSwitch = 0, swapThought = 0;
var ele, unedited, currentChar, colorcode;
var edited = "";
var areaText = 0;
var colorArr;

//Start
setup();

function setup(){
	createBackup();
	chrome.storage.sync.get({"color": []}, function(result) {
		console.log('Storage currently is ' + result.color);
		if(typeof(result.color) != undefined) {
		    colorArr = JSON.parse(result.color);
			DetectBox();
			addColor();
		}
	});
}

		
function createBackup() {
	chrome.storage.sync.set({"backup": unedited}, function() {
          console.log('Backup is ::::   ' + unedited);
        });
}

function DetectBox(){
		ele = document.getElementsByClassName('redactor-editor');
		unedited = ele[0].innerHTML;
}

function clearCode(textToClear) {
	alignSwitch = 0;
	var editedClear = "";
	for(var i = 0; i <= textToClear.length -1; i++) {
		currentChar = textToClear.charAt(i);
		
		
		if(currentChar == '[') {
			alignSwitch = 1;
			} else if(currentChar == ']'){
				alignSwitch = 0;
				continue;
			}
			
		if(alignSwitch == 0) {
			editedClear = editedClear + currentChar;
		}
		
	}
	return editedClear;
}


function addColor(){
    var changed = false;
	chrome.storage.sync.get("setClear", function(result) {
	console.log('Clear currently is ' + result.setClear);

		 console.log('Value0 is: ' + colorArr[0].color);

		if(result.setClear == true){
			unedited = clearCode(unedited);
		}
		for(var i = 0; i <= unedited.length -1; i++) {
			currentChar = unedited.charAt(i);
			changed = false;
			for(var x = 0; x <= colorArr.length -1; x++) {
			    console.log('current start is: ' + colorArr[x].start);
                if(currentChar == colorArr[x].start && swap == 0 && colorArr[x].mode == true) {
                    swap = 1;
                    edited = edited + "[color=" + colorArr[x].color + "]" + currentChar;
                    changed = true;
                } else if(currentChar == colorArr[x].end && swap == 1 && colorArr[x].mode == true){
                    swap = 0;
                    edited = edited + currentChar + "[/color]";
                    changed = true;
                }else if(currentChar == colorArr[x].start && swapThought == 0 && colorArr[x].mode == false) {
                    swapThought = 1;
                    edited = edited + "[color=" + colorArr[x].color + "]";
                    changed = true;
                } else if(currentChar == colorArr[x].end && swapThought == 1 && colorArr[x].mode == false) {
                    swapThought = 0;
                    edited = edited + "[/color]";
                    changed = true;
                }
            }
            if(changed == false) {
                edited = edited + currentChar;

            }

		}
		ele[0].innerHTML = "[align=justify]" + edited + "[/align]";
		
	});
	
	
}