

var colorArr = [];
window.addEventListener('load', function load(event) {
    	chrome.storage.sync.get("color", function(result) {

            if (result != undefined && result.color != undefined) {
                colorArr = JSON.parse(result.color);
                for(var i = 1; i <= 3; i++) {
                    document.getElementById('colorc' + i).value = colorArr[i -1].color;
                    document.getElementById('charBegin' + i).value = colorArr[i -1].start;
                    document.getElementById('charEnd' + i).value = colorArr[i -1].end;
                    document.getElementById('mode' + i).checked = colorArr[i -1].mode;
                }
            }
        });


	chrome.storage.sync.get("setClear", function(result) {
        if (result != undefined) {
			document.getElementById('setClear').checked = result.setClear;
			console.log('value is ' + result.setClear);
        }
    });

/**
	//Enable Save
	document.getElementById('colorc1').onchange = function() {
	    for(var i = 1; i <= 3; i++) {
		  if(document.getElementById('colorc' + i).value.length !== 7 || document.getElementById('colorc' + i).value.charAt(0) !== '#') {
			document.getElementById('save').disabled = true;
		  } else {
			 document.getElementById('save').disabled = false;
		  }
	}
	});
**/

	//Save and upload
    document.getElementById('save').onclick = function() {
    for(var i = 1; i <= 3; i++) {
        colorArr[i - 1] = {
            color : document.getElementById('colorc' + i).value,
            start : document.getElementById('charBegin' + i).value,
            end : document.getElementById('charEnd' + i).value,
            mode : document.getElementById('mode' + i).checked
        };
    }


    //Set Storage
     chrome.storage.sync.set({"color": JSON.stringify(colorArr), "setClear": document.getElementById('setClear').checked}, function() {
          console.log('Value is set to ' + document.getElementById('colorc1').value + " and " + document.getElementById('setClear').checked);
		  console.log('Value.length: ' + document.getElementById('colorc1').value.length);
        });

    };
	//get Backup
	chrome.storage.sync.get("backup", function(result) {
        if (result != undefined) {
            document.getElementById('backup').value = result.backup;
        }
    });
});